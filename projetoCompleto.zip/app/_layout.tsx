import { Stack } from "expo-router";
import { themes } from "../global/themes";

export default function Layout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: themes.colors.primary },
        headerTintColor: themes.colors.white,
        contentStyle: { backgroundColor: themes.colors.background },
      }}
    />
  );
}
